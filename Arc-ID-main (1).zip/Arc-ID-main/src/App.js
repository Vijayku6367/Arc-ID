import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import { ethers } from "ethers";

import NavBar from "./components/NavBar";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Showcase from "./components/Showcase";
import HowItWorks from "./components/HowItWorks";
import Footer from "./components/Footer";

import ParticlesBackground from "./components/ParticlesBackground";
import PageTransition from "./components/PageTransition";

import Task from "./Task";
import Leaderboard from "./Leaderboard";
import Profile from "./Profile";

import XPBurst from "./components/XPBurst";
import RewardConfetti from "./components/RewardConfetti";
import Toast from "./components/Toast";

import taskABI from "./contractABI.json";

const taskAddress = "0x8aE17452fc06b5911395A747Aac2fa87D62f5996";

function App() {
  const [account, setAccount] = useState(null);
  const [userXP, setUserXP] = useState(0);

  const [burstXP, setBurstXP] = useState(0);
  const [toast, setToast] = useState("");
  const [confetti, setConfetti] = useState(false);

  const connectWallet = async () => {
    if (!window.ethereum) {
      alert("Install MetaMask");
      return;
    }

    const provider = new ethers.BrowserProvider(window.ethereum);
    const accounts = await provider.send("eth_requestAccounts", []);
    setAccount(accounts[0]);

    loadXP(accounts[0]);
  };

  const loadXP = async (address) => {
    if (!window.ethereum) return;

    const provider = new ethers.BrowserProvider(window.ethereum);
    const contract = new ethers.Contract(taskAddress, taskABI, provider);

    const xpVal = await contract.xp(address);
    setUserXP(Number(xpVal));
  };

  const getLevel = () => {
    if (userXP >= 100) return 4;
    if (userXP >= 50) return 3;
    if (userXP >= 20) return 2;
    if (userXP >= 1) return 1;
    return 0;
  };

  const level = getLevel();

  const triggerReward = (reward) => {
    setBurstXP(reward);
    setConfetti(true);
    setToast("Mission Completed!");

    setTimeout(() => setBurstXP(0), 1500);
    setTimeout(() => setConfetti(false), 2000);
    setTimeout(() => setToast(""), 2400);
  };

  return (
    <div className="app">
      <ParticlesBackground />

      <XPBurst show={burstXP > 0} amount={burstXP} />
      <RewardConfetti show={confetti} />
      <Toast message={toast} />

      <NavBar account={account} connectWallet={connectWallet} />

      <Routes>
        <Route
          path="/"
          element={
            <PageTransition>
              <Hero account={account} connectWallet={connectWallet} level={level} userXP={userXP} />
              <Features />
              <Showcase />
              <HowItWorks />
              <Footer />
            </PageTransition>
          }
        />

        <Route
          path="/tasks"
          element={
            <PageTransition>
              <Task account={account} triggerReward={triggerReward} refreshXP={() => loadXP(account)} />
            </PageTransition>
          }
        />

        <Route
          path="/leaderboard"
          element={
            <PageTransition>
              <Leaderboard />
            </PageTransition>
          }
        />

        <Route
          path="/profile"
          element={
            <PageTransition>
              <Profile account={account} userXP={userXP} level={level} />
            </PageTransition>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
    
